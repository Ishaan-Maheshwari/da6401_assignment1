# my_nn/__init__.py
from .model import NeuralNetwork
from .dataset import load_dataset
from .trainer import train_model
